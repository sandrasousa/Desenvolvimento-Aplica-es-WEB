$(()=>{
    $('#fichs').load('http://localhost:4006/fich')

    $('#adicionar').click(e => {
        e.preventDefault()
        $('#desc').append('<li>' + $('#texto').val() + '</li>')
        $('#fichs').append('<a>' + $('#ficheiro').val() + '</a>')
        ajaxPost()
    })

   function ajaxPost(){
        $.ajax({
            type: "POST",
            contentType: "application/json",
            url: "http://localhost:4006/fich/guardar",
            data: JSON.stringify({fich: $('#texto').val()},
            {fich: $('#ficheiro').val()}),
            dataType: 'json',
            success: f => alert(JSON.stringify(f)),
            error: e => {
                alert('Erro no post: ' + e)
                console.log("Erro no post: " + e)
            }
        })
        $('#texto').val(''), $('#ficheiro').val('')
    }
})