var express = require('express');
var router = express.Router();
var jsonfile = require('jsonfile')

var myBD = __dirname + '/fichs.json'

/* GET home page. */
router.get('/', (req, res, next) => res.render('index'))

router.get('/fich', (req,res)=>{
  jsonfile.readFile(myBD, (erro, fichs)=>{
    if(!erro) res.render('lista', {lista: fichs})
    else res.render('error', {e: erro})
  })
})

router.post('/fich/guardar', (req,res)=>{
  var f = req.body.fich
  
  jsonfile.readFile(myBD, (erro, fichs)=>{
    if(!erro){
      fichs.push(f)
      console.dir(fichs)
      jsonfile.writeFile(myBD, fichs, erro2=>{
        if(!erro2) console.log('Ficheiro gravado com sucesso.')
        else console.log('Erro: ' + erro2)
      })
    }
    else{
      console.log('Erro: ' + e)
    }
  })
  res.json(f)
})

module.exports = router;
